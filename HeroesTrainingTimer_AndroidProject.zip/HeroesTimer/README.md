# Heroes Training Timer — proyecto Android

Aplicación Android para utilizar el cronómetro de Heroes Training durante clases y transmitir la pantalla a una TV. El proyecto incorpora el logo proporcionado.

## Funciones
- Cuenta regresiva configurable.
- Cronómetro ascendente.
- EMOM con duración total configurable.
- Tabata configurable por tiempo de trabajo, descanso y rondas.
- Intervalos configurables.
- Modo Personalizado con trabajo, descanso y rondas ajustables.
- Colores del timer y del fondo configurables.
- Sonidos beep digital, doble beep, tono grave o silencio.
- Avisos sonoros durante los últimos tres segundos de cada cuenta/fase y al cambiar de fase o terminar.
- Pantalla de reproducción a pantalla completa con logo, tiempo grande, estado TRABAJO/DESCANSO y ronda actual cuando corresponde.
- Orientación adaptable (incluye horizontal) y pantalla encendida mientras la app está abierta.

## Generar el instalador APK
Este ZIP contiene el código fuente de Android Studio; no es todavía un archivo APK instalable. Para compilarlo se necesita una computadora con Android Studio y Android SDK:
1. Descomprime el ZIP.
2. Abre la carpeta `HeroesTimer` desde Android Studio.
3. Espera a que Gradle sincronice el proyecto.
4. Selecciona **Build > Build APK(s)**.
5. Android Studio generará el APK de depuración en `app/build/outputs/apk/debug/app-debug.apk`.

## Transmitir a la TV
Usa la función de duplicar pantalla/Transmitir del teléfono Android o un dispositivo de transmisión compatible. Para una TV horizontal, gira el teléfono a horizontal y verifica que la duplicación respete esa orientación. El resultado depende del teléfono y del dispositivo de transmisión.

## Nota
No se ha compilado ni probado en un dispositivo físico desde este entorno. Revisa el funcionamiento del sonido y la duplicación de pantalla en el equipo donde se vaya a utilizar.
